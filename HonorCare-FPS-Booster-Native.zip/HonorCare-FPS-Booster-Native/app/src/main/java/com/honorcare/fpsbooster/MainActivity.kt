package com.honorcare.fpsbooster

import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.StatFs
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 19, 24)
    private val panel = Color.rgb(27, 34, 43)
    private val green = Color.rgb(140, 240, 176)
    private val fg = Color.rgb(243, 246, 250)
    private val muted = Color.rgb(174, 185, 198)
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var metrics: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        label(root, "HONOR CARE · FPS BOOSTER", 13f, green, true, 0, 4)
        label(root, "Подготовка к Roblox", 28f, fg, true, 0, 6)
        label(root, "Honor 90 Lite · Android 13 · без root", 14f, muted, false, 0, 16)

        val hero = card()
        label(hero, "Цель: более стабильные 60 FPS", 19f, fg, true, 0, 8)
        label(hero, "Безопасная подготовка к игре. Приложение не разгоняет CPU/GPU и не обещает снять лимит FPS.", 14f, muted, false, 0, 10)
        button(hero, "Обновить сведения", green) { refreshMetrics() }
        status = label(hero, "Готово к проверке.", 13f, muted, false, 8, 0)

        val info = card()
        label(info, "Сведения устройства", 19f, fg, true, 0, 8)
        metrics = label(info, "Загрузка…", 14f, muted, false, 0, 0)

        val tips = card()
        label(tips, "Настройки для стабильного FPS", 19f, fg, true, 0, 8)
        label(tips, "1. В Roblox открой Settings → Graphics Mode → Manual и снижай Graphics Quality, пока игра не станет плавнее.", 14f, muted, false, 0, 8)
        label(tips, "2. Закрой тяжёлые фоновые приложения и останови ненужные загрузки/запись экрана.", 14f, muted, false, 0, 8)
        label(tips, "3. При сильном нагреве сделай паузу: тепловое ограничение может снижать FPS.", 14f, muted, false, 0, 8)
        label(tips, "4. Энергосбережение может ограничивать производительность; отключение быстрее расходует заряд.", 14f, muted, false, 0, 10)
        button(tips, "Открыть настройки батареи", panel) { openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }
        button(tips, "Открыть настройки экрана", panel) { openSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        button(tips, "Настройки приложения Roblox", panel) {
            openSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:com.roblox.client")))
        }
        button(tips, "Запустить Roblox", green) { launchRoblox() }

        val limits = card()
        label(limits, "Честные ограничения", 19f, fg, true, 0, 8)
        label(limits, "Без root обычное приложение не может напрямую задавать частоты CPU/GPU, гарантировать 60 FPS, обходить ограничение кадров Roblox или очищать кэш других приложений. 90 Гц экрана не гарантируют 90 FPS в игре.", 14f, muted, false, 0, 0)
        label(root, "Неофициальный помощник. Не связан с Roblox или HONOR.", 12f, muted, false, 8, 0)
        refreshMetrics()
    }

    private fun card(): LinearLayout {
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.bottomMargin = dp(12)
        root.addView(v, p)
        return v
    }

    private fun label(parent: LinearLayout, value: String, size: Float, color: Int,
                      bold: Boolean, top: Int, bottom: Int): TextView {
        val v = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(top), 0, dp(bottom))
        }
        parent.addView(v, LinearLayout.LayoutParams(-1, -2))
        return v
    }

    private fun button(parent: LinearLayout, value: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply {
            text = value
            isAllCaps = false
            textSize = 14f
            setTextColor(if (color == green) Color.rgb(8, 32, 20) else fg)
            setBackgroundColor(color)
            setOnClickListener { action() }
        }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.topMargin = dp(5)
        parent.addView(b, p)
    }

    private fun refreshMetrics() {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) "${level * 100 / scale}%" else "недоступно"
        val charging = when (b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
            BatteryManager.BATTERY_STATUS_CHARGING, BatteryManager.BATTERY_STATUS_FULL -> "да"
            else -> "нет / неизвестно"
        }
        val stat = StatFs(filesDir.absolutePath)
        val free = stat.availableBytes / (1024.0 * 1024.0 * 1024.0)
        val total = stat.totalBytes / (1024.0 * 1024.0 * 1024.0)
        @Suppress("DEPRECATION")
        val hz = try { windowManager.defaultDisplay.refreshRate } catch (_: Exception) { 0f }
        metrics.text = String.format(Locale.getDefault(),
            "Заряд: %s\nЗаряжается: %s\nЧастота обновления экрана: %.0f Гц\nСвободно во внутреннем хранилище: %.1f ГБ из %.1f ГБ",
            pct, charging, hz, free, total)
        status.text = "Обновлено. Реальный FPS Roblox не измеряется."
    }

    private fun launchRoblox() {
        val launch = packageManager.getLaunchIntentForPackage("com.roblox.client")
        if (launch != null) startActivity(launch)
        else status.text = "Roblox не найден. Установи его из официального магазина."
    }

    private fun openSettings(intent: Intent) {
        try { startActivity(intent) }
        catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            catch (_: Exception) { status.text = "Не удалось открыть настройки." }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
