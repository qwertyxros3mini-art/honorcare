plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.honorcare.fpsbooster"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.honorcare.fpsbooster"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
}
